from . import section_labels
from .inp import read_inp_file, SwmmInput

SEC = section_labels
