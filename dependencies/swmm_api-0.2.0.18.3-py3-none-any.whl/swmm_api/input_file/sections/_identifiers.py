class IDENTIFIERS:
    """predefined to identify the objects in an input file section and also used in the tags section"""
    Name = 'Name'

    Node = 'Node'
    Subcatch = 'Subcatch'
    Link = 'Link'

    Gage = 'Gage'

    Constituent = 'Constituent'

    Pollutant = 'pollutant'

    Landuse = 'landuse'
